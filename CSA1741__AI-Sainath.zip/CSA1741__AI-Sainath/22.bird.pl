canfly(sparrow).
canfly(eagle).
canfly(peacock).

cannotfly(ostrich).
cannotfly(penguin).
